## Tilesets in Mapbox - Python

The document intends to explain the set up and functioning of the python script to create tilesets in mapbox with a given source file in  a specific format.

To start with, there needs to be python 3.6 or above version installed.
Post that, the requirements listed in requirements.txt need to be pip installed as -
   pip install <requirement> 
   
This will ensure the dependencies are downloaded and installed.

**Few informative details -**

The input folder contains raw co-ordinates, which in turn after processing will be stored in geoJson directory created at run time.

The config directory will contain parameters to log in to mapbox account and various mapbox API's. 

The scripts directory will contain the actual script and src will have an app.py file that will wrap the script around rest API.

The output folder will contain the created tileset stored as a json object in a file output.json.

**Running the Script**

- Go to src folder in cloned repository, hit cmd prompt and run the following command - python app.py
- Make GET API call http://localhost:4007/triggerTileset
- This will trigger the internal script TilesetMapbox.py and create the tilesets in Mapbox and update the entry in output folder.

We will have the logs created in the logs folder in the same directory where app.py file resides.
