import json
import logging
import os
import time
from io import StringIO
import requests


def initialTrigger():
    def logMethod():
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        return logger

    # deleting previous source data
    def deleteSourceData(deleteUrl):
        requests.delete(deleteUrl)

    # Method to createSource Data for mapbox API
    def createSourceData(createUrl, lineDelimitedJson):
        time.sleep(configParameters['waitTimeTileset'])
        requestSource = requests.post(createUrl, files={"file": lineDelimitedJson})
        logMethod().info(requestSource.text)

    # Method to initialize tilesets in mapbox
    def addTilesetMapbox(timeStamp):
        headers = {'Content-Type': 'application/json', }
        # Handling recipe file at runtime to avoid new terminal client addition dependency
        recipe = configParameters['recipeString']
        tileSetName = str(configParameters['userId'] + '.' + 'sampleTileset_' + timeStamp)
        CreateTilesetUrl = str(configParameters['createTileset'].format(tileSetName, configParameters['userKey']))
        data_Params = json.dumps(recipe)
        time.sleep(configParameters['waitTimeTileset'])
        responseTileset = requests.post(CreateTilesetUrl, headers=headers, data=data_Params)
        logMethod().info(responseTileset.text)
        publishTilest(tileSetName)

    # API call to publish tileset in mapbox
    def publishTilest(tileSetName):
        PublishTilesetUrl = str(configParameters['publishTileset'].format(tileSetName, configParameters['userKey']))
        time.sleep(configParameters['waitTimeTileset'])
        responsePublish = requests.post(PublishTilesetUrl)
        responsePublishDict = json.loads(responsePublish.text)
        logMethod().info(responsePublish.text)

        trackJobList.append(tileSetName)
        trackJobList.append(responsePublishDict)

    # Method to handle mapbox requests
    def createTilesets():
        with open(str(relativePath.replace('src', 'src/geoJson/') + 'geoJson.json')) as inFile:
            geo = json.load(inFile)

            # Creating line-delimited geoJson
        with StringIO() as io:
            for feature in geo:
                io.write((json.dumps(feature) + "\n"))
                lineDelimitedJson = io.getvalue()

        timeStamp = str(int(time.time()))
        # URL to add line delimited source for geoJson
        createTilesetSourceUrl = str(
            configParameters['createTilesetSource'].format(configParameters['userId'], 'Tileset_Source',
                                                           configParameters['userKey']))

        # Call the delete API in mapbox
        deleteSourceData(createTilesetSourceUrl)

        # Call the add source data API in mapbox
        createSourceData(createTilesetSourceUrl, lineDelimitedJson)

        # Create the empty tilesets
        addTilesetMapbox(timeStamp)

    # Reading present working directory and initializing logs
    relativePath = os.getcwd()
    logTimeStamp = str(int(time.time()))
    logging.basicConfig(filename=relativePath.replace('src', 'src/logs/') + 'log_' + logTimeStamp + '.log',
                        level=logging.ERROR)

    try:
        # Reading rawCoordinates data
        with open(str(relativePath.replace('src', 'src/input/') + 'RawCoordinatesBangalore.json')) as infile:
            raw = json.load(infile)
        logMethod().info('Reading input data')

        with open(str(relativePath.replace('src', 'src/config/') + 'Config.json')) as config:
            configParameters = json.load(config)

        # Creating empty list to append to geoJson source
        geoList = []
        geoPolyList = []
        geoJsonList = []
        geoLineList = []
        trackJobList = []

        # Reading through all the coordinates and forming raw geoJson file for input to mapbox APIs
        for i in range(0, len(raw)):
            if 'Polygon' in raw[i]:
                for j in range(0, len(raw[i]['Polygon'])):
                    lat = raw[i]['Polygon'][j]['gpsCoordinates']['latitude']
                    long = raw[i]['Polygon'][j]['gpsCoordinates']['longitude']
                    geoList.append(long)
                    geoList.append(lat)
                    geoPolyList.append(geoList)
                    geoList = []
                geoJson = {'type': 'Feature', 'properties': {'name': 'Polygon'},
                           'geometry': {'type': 'Polygon', 'coordinates': [geoPolyList]}}
                geoJsonList.append(geoJson)
            elif 'LineString' in raw[i]:
                for j in range(0, len(raw[i]['LineString'])):
                    lat = raw[i]['LineString'][j]['gpsCoordinates']['latitude']
                    long = raw[i]['LineString'][j]['gpsCoordinates']['longitude']
                    geoList.append(long)
                    geoList.append(lat)
                    geoLineList.append(geoList)
                    geoList = []
                geoJson = {'type': 'Feature', 'properties': {'name': 'LineString'},
                           'geometry': {'type': 'LineString', 'coordinates': geoLineList}}
                geoJsonList.append(geoJson)
            else:
                for j in range(0, len(raw[i]['Point'])):
                    lat = raw[i]['Point'][j]['gpsCoordinates']['latitude']
                    long = raw[i]['Point'][j]['gpsCoordinates']['longitude']
                    geoList.append(long)
                    geoList.append(lat)
                    geoJson = {'type': 'Feature', 'properties': {'name':raw[i]['Point'][j]['gpsCoordinates']['name']},
                               'geometry': {'type': 'Point', 'coordinates': geoList}}
                    geoList = []
                    geoJsonList.append(geoJson)
        logMethod().info('Saving data to geoJson directory')
        with open(relativePath.replace('src', 'src/geoJson/' + 'geoJson.json'), 'w') as outfile:
            json.dump(geoJsonList, outfile)
        # Calling APIs for mapbox
        createTilesets()

        # Track the status of the tilesets getting  published in mapbox server
        trackJobSuccessList = []
        trackJobDictList = []
        counter = set(())
        for count in range(0, configParameters['trackCountParameter']):
            trackJob = requests.get(
                str(configParameters['trackJob'].format(trackJobList[0], trackJobList[1]['jobId'],
                                                        configParameters['userKey'])))
            null = "Ongoing"
            trackJobText = (trackJob.text.replace(null, null))
            trackJobDict = eval(trackJobText)
            if trackJobDict['stage'] == "success":
                counter.add(trackJobList[0])
                trackJobSuccessList.append(trackJobDict)
            else:
                trackJobDictList.append(trackJobDict)
                time.sleep(configParameters['waitTimeTilesetStatus'])

            if len(counter) == 1:
                response = {"tileset": trackJobList[0]}
                with open((relativePath.replace('src', 'src/output/') + 'Output.json'), 'w') as outfile:
                    json.dump(response, outfile)
                logMethod().info(trackJobSuccessList)
                print('Tileset published in Mapbox successfully')
                break
            else:
                logMethod().info('Tilesets are getting published in mapbox server')
                time.sleep(configParameters['trackSleepParameter'])

        if len(counter) != 1:
            logMethod().error(trackJobDictList)
            logMethod().error('Time elapsed and tilesets were not successfully published in mapbox server')

    except Exception as e:
        logging.exception(str(e))
