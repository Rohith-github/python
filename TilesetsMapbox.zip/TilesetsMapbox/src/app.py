import threading
import src.scripts.TilesetMapbox as script

from flask import Flask
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Application variables
host = '0.0.0.0'
port = 7002

@app.route('/triggerTileset', methods=['GET'])
def create_Tileset():

    def python_init():
        # Calling script in a different thread
        script.initialTrigger()

    thread = threading.Thread(target=python_init)
    thread.start()
    return 'Initiated python script to create tilesets'


if __name__ == '__main__':
    app.run(host=host,port=port)
